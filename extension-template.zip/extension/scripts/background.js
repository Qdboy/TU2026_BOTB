// scripts/background.js
// ============================================
// Service worker.
// - Relays messages between content scripts
// - Handles all backend API calls (content
//   scripts can't make cross-origin requests
//   reliably, so they go through here)
// ============================================

// ---- Config ----

let config = {
  baseUrl: 'http://localhost:8000',
  apiKey: '',
};

chrome.storage.local.get('backendConfig', (result) => {
  if (result.backendConfig) Object.assign(config, result.backendConfig);
});

// Update config when it changes
chrome.storage.onChanged.addListener((changes) => {
  if (changes.backendConfig) {
    Object.assign(config, changes.backendConfig.newValue);
  }
});

// ---- Backend Fetch ----

async function backendRequest(endpoint, method = 'GET', body = null) {
  const url = `${config.baseUrl}${endpoint}`;
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(config.apiKey && { 'X-API-Key': config.apiKey }),
    },
  };

  if (body) options.body = JSON.stringify(body);

  const response = await fetch(url, options);
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(`${response.status}: ${text}`);
  }
  return response.json();
}

// ---- Message Router ----
// Content scripts send messages here.
// Pattern: { type: 'BACKEND_REQUEST', endpoint, method, body }

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  switch (msg.type) {

    // Proxy a request to the Python backend
    case 'BACKEND_REQUEST':
      backendRequest(msg.endpoint, msg.method || 'GET', msg.body)
        .then((data) => sendResponse({ ok: true, data }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true; // async

    // Store data (content script → storage)
    case 'STORE':
      chrome.storage.local.set({ [msg.key]: msg.value }, () => {
        sendResponse({ ok: true });
      });
      return true;

    // Retrieve data (storage → content script)
    case 'LOAD':
      chrome.storage.local.get(msg.key, (result) => {
        sendResponse({ ok: true, data: result[msg.key] || null });
      });
      return true;

    // Relay between content scripts (e.g., shopping page → AI chat)
    case 'RELAY':
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.id !== sender.tab?.id) {
            chrome.tabs.sendMessage(tab.id, msg.payload).catch(() => {});
          }
        }
      });
      sendResponse({ ok: true });
      return false;

    default:
      sendResponse({ ok: false, error: 'Unknown message type' });
  }
});

// ---- Install ----

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      backendConfig: config,
      settings: { enabled: true },
    });
    console.log('[bg] Extension installed.');
  }
});
