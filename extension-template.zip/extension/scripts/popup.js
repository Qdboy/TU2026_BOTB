// scripts/popup.js

const baseUrlInput = document.getElementById('baseUrl');
const apiKeyInput  = document.getElementById('apiKey');
const toggle       = document.getElementById('enableToggle');
const saveBtn      = document.getElementById('saveBtn');
const testBtn      = document.getElementById('testBtn');
const statusEl     = document.getElementById('status');

let enabled = true;

// ---- Load saved settings ----
chrome.storage.local.get(['backendConfig', 'settings'], (result) => {
  const cfg = result.backendConfig || {};
  baseUrlInput.value = cfg.baseUrl || 'http://localhost:8000';
  apiKeyInput.value  = cfg.apiKey || '';

  enabled = result.settings?.enabled !== false;
  toggle.classList.toggle('on', enabled);
});

// ---- Toggle ----
toggle.addEventListener('click', () => {
  enabled = !enabled;
  toggle.classList.toggle('on', enabled);
});

// ---- Save ----
saveBtn.addEventListener('click', () => {
  const config = {
    baseUrl: baseUrlInput.value.replace(/\/+$/, ''),
    apiKey: apiKeyInput.value,
  };

  chrome.storage.local.set({
    backendConfig: config,
    settings: { enabled },
  }, () => {
    showStatus('Saved', false);
  });
});

// ---- Test Connection ----
testBtn.addEventListener('click', async () => {
  const url = baseUrlInput.value.replace(/\/+$/, '') + '/health';
  const key = apiKeyInput.value;

  showStatus('Testing...', false);

  try {
    const response = await fetch(url, {
      headers: key ? { 'X-API-Key': key } : {},
    });

    if (response.ok) {
      showStatus('Connected', false);
    } else {
      showStatus(`Error: ${response.status}`, true);
    }
  } catch (err) {
    showStatus('Cannot reach backend', true);
  }
});

function showStatus(text, isError) {
  statusEl.textContent = text;
  statusEl.className = 'status' + (isError ? ' error' : '');
  setTimeout(() => { statusEl.textContent = ''; }, 3000);
}
