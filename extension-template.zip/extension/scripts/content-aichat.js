// scripts/content-aichat.js
// ============================================
// Runs on AI chat sites (ChatGPT, Claude, Gemini).
// Observes the conversation and calls your
// Python backend when relevant.
//
// Extend the TODO sections with your logic.
// ============================================

(function () {
  'use strict';

  // ---- Helpers: talk to background script ----

  function callBackend(endpoint, method, body) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'BACKEND_REQUEST', endpoint, method, body },
        (res) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          res?.ok ? resolve(res.data) : reject(new Error(res?.error || 'Request failed'));
        }
      );
    });
  }

  function store(key, value) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'STORE', key, value }, resolve);
    });
  }

  function load(key) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'LOAD', key }, (res) => resolve(res?.data));
    });
  }

  // ---- Platform Detection ----

  function detectPlatform() {
    const host = window.location.hostname;
    if (host.includes('chatgpt.com') || host.includes('chat.openai.com')) return 'chatgpt';
    if (host.includes('claude.ai')) return 'claude';
    if (host.includes('gemini.google.com')) return 'gemini';
    return null;
  }

  // ---- DOM Selectors Per Platform ----
  // Update these when a site changes its markup.

  const SELECTORS = {
    chatgpt: {
      container: 'main',
      turn: '[data-testid^="conversation-turn"]',
      userMsg: '[data-message-author-role="user"]',
      assistantMsg: '[data-message-author-role="assistant"]',
      content: '.markdown',
    },
    claude: {
      container: '[data-testid="conversation-content"]',
      turn: '.group',
      userMsg: '[data-testid="user-message"]',
      assistantMsg: '[data-testid="assistant-message"]',
      content: '.prose',
    },
    gemini: {
      container: 'main',
      turn: 'message-content',
      userMsg: '.user-message',
      assistantMsg: '.model-response',
      content: '.response-content',
    },
  };

  // ---- Conversation Observer ----

  function observeConversation(platform, onUserMessage, onAssistantMessage) {
    const sel = SELECTORS[platform];
    if (!sel) return;

    const container = document.querySelector(sel.container);
    if (!container) {
      console.warn(`[aichat] Container not found for ${platform}. Retrying...`);
      setTimeout(() => observeConversation(platform, onUserMessage, onAssistantMessage), 2000);
      return;
    }

    const processed = new WeakSet();

    function scanTurn(turnEl) {
      if (processed.has(turnEl)) return;
      processed.add(turnEl);

      const userEl = turnEl.querySelector(sel.userMsg);
      const assistantEl = turnEl.querySelector(sel.assistantMsg);

      if (userEl) {
        onUserMessage(userEl.innerText.trim(), turnEl);
      }
      if (assistantEl) {
        const content = turnEl.querySelector(sel.content);
        onAssistantMessage(content?.innerText.trim() || '', turnEl, content);
      }
    }

    // Scan existing turns
    container.querySelectorAll(sel.turn).forEach(scanTurn);

    // Watch for new turns
    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          if (node.matches?.(sel.turn)) scanTurn(node);
          node.querySelectorAll?.(sel.turn)?.forEach(scanTurn);
        }
      }
    });

    observer.observe(container, { childList: true, subtree: true });
    console.log(`[aichat] Observing ${platform} conversation.`);
  }

  // ---- Overlay Injection ----
  // Call this to inject your custom UI into the chat.

  function injectOverlay(targetEl, html) {
    // Don't double-inject
    if (targetEl.nextElementSibling?.classList.contains('ext-overlay')) return;

    const overlay = document.createElement('div');
    overlay.className = 'ext-overlay';
    overlay.innerHTML = html;
    targetEl.parentNode.insertBefore(overlay, targetEl.nextSibling);
    return overlay;
  }

  // ---- Boot ----

  function boot() {
    const platform = detectPlatform();
    if (!platform) return;

    console.log(`[aichat] Running on ${platform}`);

    let lastUserText = '';

    observeConversation(
      platform,

      // ---- User sent a message ----
      (text, turnEl) => {
        lastUserText = text;
        console.log('[aichat] User:', text.slice(0, 80));

        // TODO: Detect shopping intent here or send to backend
        // Example:
        // callBackend('/detect-intent', 'POST', { text })
        //   .then(result => { ... })
        //   .catch(err => console.error(err));
      },

      // ---- Assistant responded ----
      (text, turnEl, contentEl) => {
        console.log('[aichat] Assistant:', text.slice(0, 80));

        // TODO: Process the response, enrich it, inject UI
        // Example:
        // if (shoppingIntentDetected) {
        //   callBackend('/enrich', 'POST', { query: lastUserText, response: text })
        //     .then(enriched => {
        //       injectOverlay(contentEl || turnEl, buildProductCards(enriched));
        //     });
        // }
      }
    );
  }

  // Give SPAs time to render
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 1500));
  } else {
    setTimeout(boot, 1500);
  }

})();
