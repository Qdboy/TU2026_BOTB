// scripts/content-shop.js
// ============================================
// Runs on shopping sites (Amazon, Best Buy, etc).
// Reads product info from the page, sends it
// to your backend, and injects enhanced UI.
//
// Extend the TODO sections with your logic.
// ============================================

(function () {
  'use strict';

  // ---- Helpers: talk to background script ----

  function callBackend(endpoint, method, body) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'BACKEND_REQUEST', endpoint, method, body },
        (res) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          res?.ok ? resolve(res.data) : reject(new Error(res?.error || 'Request failed'));
        }
      );
    });
  }

  function store(key, value) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'STORE', key, value }, resolve);
    });
  }

  function load(key) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'LOAD', key }, (res) => resolve(res?.data));
    });
  }

  // ---- Site Detection ----

  function detectSite() {
    const host = window.location.hostname;
    if (host.includes('amazon.com'))  return 'amazon';
    if (host.includes('bestbuy.com')) return 'bestbuy';
    if (host.includes('walmart.com')) return 'walmart';
    if (host.includes('target.com'))  return 'target';
    if (host.includes('ebay.com'))    return 'ebay';
    return null;
  }

  // ---- Product Data Extractors ----
  // Each returns { name, price, rating, specs, url } or null.
  // These selectors break when sites update — check here first.

  const EXTRACTORS = {

    amazon() {
      const name = document.querySelector('#productTitle')?.innerText.trim();
      const price = document.querySelector('.a-price .a-offscreen')?.innerText.trim();
      const rating = document.querySelector('#acrPopover .a-icon-alt')?.innerText.trim();
      if (!name) return null;
      return { name, price, rating, url: window.location.href, specs: null };
    },

    bestbuy() {
      const name = document.querySelector('.sku-title h1')?.innerText.trim();
      const price = document.querySelector('.priceView-customer-price span')?.innerText.trim();
      const rating = document.querySelector('.c-stars-v4')?.getAttribute('aria-label');
      if (!name) return null;
      return { name, price, rating, url: window.location.href, specs: null };
    },

    walmart() {
      const name = document.querySelector('[itemprop="name"]')?.innerText.trim();
      const price = document.querySelector('[itemprop="price"]')?.innerText.trim();
      if (!name) return null;
      return { name, price, rating: null, url: window.location.href, specs: null };
    },

    target() {
      const name = document.querySelector('[data-test="product-title"]')?.innerText.trim();
      const price = document.querySelector('[data-test="product-price"]')?.innerText.trim();
      if (!name) return null;
      return { name, price, rating: null, url: window.location.href, specs: null };
    },

    ebay() {
      const name = document.querySelector('.x-item-title__mainTitle span')?.innerText.trim();
      const price = document.querySelector('.x-price-primary span')?.innerText.trim();
      if (!name) return null;
      return { name, price, rating: null, url: window.location.href, specs: null };
    },
  };

  // ---- Overlay Injection ----

  function injectOverlay(anchorEl, html) {
    if (document.querySelector('.ext-overlay')) return;

    const overlay = document.createElement('div');
    overlay.className = 'ext-overlay';
    overlay.innerHTML = html;
    anchorEl.parentNode.insertBefore(overlay, anchorEl.nextSibling);
    return overlay;
  }

  // ---- Page Change Observer ----
  // SPAs and infinite scroll — re-run extraction when the page updates.

  function observePageChanges(callback) {
    let debounce = null;
    const observer = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(callback, 800);
    });
    observer.observe(document.body, { childList: true, subtree: true });
    return observer;
  }

  // ---- Boot ----

  function boot() {
    const site = detectSite();
    if (!site) return;

    console.log(`[shop] Running on ${site}`);

    function processPage() {
      const extractor = EXTRACTORS[site];
      if (!extractor) return;

      const product = extractor();
      if (!product) {
        console.log('[shop] No product data found on this page.');
        return;
      }

      console.log('[shop] Product detected:', product.name);

      // TODO: Send product data to your backend
      // Example:
      // callBackend('/product/analyze', 'POST', product)
      //   .then(analysis => {
      //     // Inject price comparison, reviews summary, etc.
      //     const anchor = document.querySelector('#productTitle') || document.body;
      //     injectOverlay(anchor, buildAnalysisUI(analysis));
      //   })
      //   .catch(err => console.error('[shop] Backend error:', err));

      // TODO: Store product for cross-tab use with AI chat
      // store('lastProduct', product);
    }

    processPage();
    observePageChanges(processPage);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 1000));
  } else {
    setTimeout(boot, 1000);
  }

})();
