# AI Shopping Extension — Template

A Chrome extension template for interacting with AI chat sites and shopping sites, backed by a Python API.

## Quick Start

### Extension
1. Open Chrome → `chrome://extensions` → toggle **Developer mode**
2. Click **Load unpacked** → select the project root folder (not `backend/`)
3. Click the extension icon → enter your backend URL and API key → Save

### Backend
```bash
cd backend
pip install fastapi uvicorn
API_KEY=your-secret-key uvicorn server:app --reload --port 8000
```

Click **Test Connection** in the extension popup to verify.

## Project Structure

```
├── manifest.json                # Manifest V3 config
├── popup.html                   # Extension popup (settings UI)
├── scripts/
│   ├── background.js            # Service worker — routes messages, proxies backend calls
│   ├── content-aichat.js        # Runs on AI chats (ChatGPT, Claude, Gemini)
│   ├── content-shop.js          # Runs on shopping sites (Amazon, Best Buy, etc.)
│   └── popup.js                 # Popup settings logic
├── styles/
│   └── overlay.css              # Shared styles for injected UI
├── utils/
│   └── backend.js               # Backend API helper (reference, used by background.js)
├── icons/                       # Extension icons
└── backend/
    └── server.py                # Python FastAPI stub matching the extension's endpoints
```

## How It Works

```
┌──────────────┐     messages      ┌──────────────┐    HTTP/JSON    ┌──────────────┐
│ Content       │ ◄──────────────► │ Background    │ ◄────────────► │ Python       │
│ Scripts       │  chrome.runtime  │ Service       │   REST + API   │ Backend      │
│              │  .sendMessage()  │ Worker        │   Key auth     │ (FastAPI)    │
├──────────────┤                  └──────────────┘                 ├──────────────┤
│ AI Chat:     │                                                   │ /health      │
│  - ChatGPT   │                                                   │ /detect-intent│
│  - Claude    │                                                   │ /enrich      │
│  - Gemini    │                                                   │ /product/    │
├──────────────┤                                                   │   analyze    │
│ Shopping:    │                                                   └──────────────┘
│  - Amazon    │
│  - Best Buy  │
│  - Walmart   │
│  - Target    │
│  - eBay      │
└──────────────┘
```

Content scripts can't make cross-origin requests reliably, so all backend calls
go through the background service worker:

```
Content script → sendMessage({ type: 'BACKEND_REQUEST', endpoint, method, body })
    → Background receives, calls fetch() to your Python backend
    → Sends response back to content script via sendResponse()
```

## Extending

### Add a new AI chat platform
1. Add URL to `content_scripts[0].matches` in `manifest.json`
2. Add detection logic in `detectPlatform()` in `content-aichat.js`
3. Add DOM selectors in the `SELECTORS` object

### Add a new shopping site
1. Add URL to `content_scripts[1].matches` in `manifest.json`
2. Add detection in `detectSite()` in `content-shop.js`
3. Add a product extractor in the `EXTRACTORS` object

### Add a new backend endpoint
1. Add the route in `backend/server.py`
2. Call it from content scripts via:
   ```js
   callBackend('/your-endpoint', 'POST', { data: '...' })
     .then(result => { /* use result */ })
   ```

## Backend Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Connection test |
| `/detect-intent` | POST | Analyze text for shopping intent |
| `/enrich` | POST | Enrich AI response with product data |
| `/product/analyze` | POST | Analyze product scraped from shopping site |

All endpoints except `/health` require `X-API-Key` header.
