// utils/backend.js
// ============================================
// Communication layer for your Python backend.
// Reads config from chrome.storage.
//
// Usage (from any script via background relay):
//   const data = await backend.post('/analyze', { text: '...' });
// ============================================

const backend = {

  // Defaults — override via popup settings or chrome.storage
  _config: {
    baseUrl: 'http://localhost:8000',
    apiKey: '',
  },

  async loadConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get('backendConfig', (result) => {
        if (result.backendConfig) {
          Object.assign(this._config, result.backendConfig);
        }
        resolve(this._config);
      });
    });
  },

  async saveConfig(updates) {
    Object.assign(this._config, updates);
    return new Promise((resolve) => {
      chrome.storage.local.set({ backendConfig: this._config }, resolve);
    });
  },

  async request(endpoint, options = {}) {
    await this.loadConfig();

    const url = `${this._config.baseUrl}${endpoint}`;
    const config = {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(this._config.apiKey && { 'X-API-Key': this._config.apiKey }),
        ...options.headers,
      },
    };

    if (options.body) {
      config.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(url, config);
      if (!response.ok) {
        const errText = await response.text().catch(() => '');
        throw new Error(`${response.status} ${response.statusText}: ${errText}`);
      }
      return await response.json();
    } catch (error) {
      console.error(`[backend] ${config.method} ${url} failed:`, error.message);
      throw error;
    }
  },

  get(endpoint)        { return this.request(endpoint, { method: 'GET' }); },
  post(endpoint, body) { return this.request(endpoint, { method: 'POST', body }); },
  put(endpoint, body)  { return this.request(endpoint, { method: 'PUT', body }); },
  del(endpoint)        { return this.request(endpoint, { method: 'DELETE' }); },
};
