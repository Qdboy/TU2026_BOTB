// ShopSmart - Response Analyzer
// JavaScript port of response_analyzer.py
// Runs entirely in the browser at export time — no server, no Python needed.

const Analyzer = (() => {

  // ── Price pattern ────────────────────────────────────────────────────────
  const PRICE_RE = /[\$£€]\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?/g;

  // ── Keyword taxonomy ─────────────────────────────────────────────────────
  const KEYWORD_TAXONOMY = {
    computing:    ["laptop", "computer", "desktop", "chromebook", "pc", "ram", "ssd", "processor", "cpu"],
    fitness:      ["treadmill", "gym", "workout", "exercise", "running", "jogging", "health", "fitness"],
    vending:      ["vending", "machine", "snack", "drink", "beverage", "combo"],
    pricing:      ["price", "cost", "affordable", "cheap", "budget", "under", "deal", "value", "$", "£", "€"],
    features:     ["foldable", "portable", "wireless", "bluetooth", "smart", "ai", "touchscreen", "motor"],
    sentiment:    ["best", "top", "great", "popular", "recommended", "trusted", "good", "excellent"],
    comparison:   ["vs", "versus", "compared", "alternative", "better", "unlike", "over"],
    product_type: ["model", "version", "series", "edition", "line", "collection"],
  };

  // ── Skip prefixes for product name filtering ─────────────────────────────
  const SKIP_STARTS = [
    "around","great","good","best","note","tip","quick","not","very",
    "usually","often","most","one of","budget","if ","drink machines",
    "typical","operators","these brands","these specs","combo machine",
    "used vending","new combo","smart vending",
  ];

  // ── Helpers ──────────────────────────────────────────────────────────────

  function extractPrices(text) {
    const matches = text.match(PRICE_RE) || [];
    return [...new Set(matches)]; // unique, preserving order
  }

  function extractKeywords(text) {
    const tl = text.toLowerCase();
    return Object.entries(KEYWORD_TAXONOMY)
      .filter(([, terms]) => terms.some(t => tl.includes(t)))
      .map(([tag]) => tag);
  }

  function detectSignals(text) {
    const tl = text.toLowerCase();
    return {
      has_price:      PRICE_RE.test(text),
      has_comparison: /\b(vs|versus|compared|better than|unlike|alternative)\b/.test(tl),
      has_sentiment:  /\b(best|top|great|popular|recommended|trusted|excellent)\b/.test(tl),
      has_features:   /\b(feature|spec|performance|design|foldable|wireless|bluetooth)\b/.test(tl),
    };
  }

  function isValidName(name) {
    if (name.length < 8) return false;
    const nl = name.toLowerCase();
    if (SKIP_STARTS.some(s => nl.startsWith(s))) return false;
    // Must contain at least one capitalized word ≥ 3 chars
    if (!/\b[A-Z][a-zA-Z]{2,}/.test(name)) return false;
    return true;
  }

  function lookAheadInfo(lines, startIdx, thisLine) {
    let price = null;
    const descParts = [];
    const window = lines.slice(startIdx, startIdx + 7);
    for (const la of window) {
      const stripped = la.trim();
      const prices = stripped.match(PRICE_RE);
      if (prices && !price) price = prices[0];
      const clean = stripped.replace(/^[•·–\-▪\s]+/, "").trim();
      if (
        clean &&
        clean.toLowerCase() !== thisLine.toLowerCase() &&
        !/^[\$£€]/.test(clean) &&
        clean.length > 5 &&
        clean !== thisLine.trim()
      ) {
        descParts.push(clean);
      }
    }
    return { price, description: descParts.slice(0, 3).join("; ") };
  }

  function extractProducts(text) {
    const lines = text.split("\n");
    const products = [];
    const seenNames = new Set();

    // Emoji/number bullet pattern
    const BULLET_RE = /^(?:\d+[️⃣°.)]\s*|[⭐🔥👉✅💡🥤🧠💻🏃💰👍⚠️✓•·–]+\s*)([A-Z][A-Za-z0-9][A-Za-z0-9 \-&+'".\/]{5,78})/;
    // Plain capitalized name
    const NAME_RE   = /^[A-Z][A-Za-z0-9][A-Za-z0-9 \-&+'".\/]{5,70}$/;

    // Pass 1 — bullet/emoji lines
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].trim().match(BULLET_RE);
      if (!m) continue;
      const name = m[1].trim().replace(/[.,:]$/, "");
      if (!isValidName(name) || seenNames.has(name.toLowerCase())) continue;
      seenNames.add(name.toLowerCase());
      const { price, description } = lookAheadInfo(lines, i, lines[i].trim());
      products.push({ name, price: price || null, description });
    }

    // Pass 2 — capitalized name followed by a price line
    for (let i = 0; i < lines.length - 1; i++) {
      const nameLine = lines[i].trim();
      if (!NAME_RE.test(nameLine)) continue;
      const name = nameLine.replace(/[.,:]$/, "");
      if (!isValidName(name) || seenNames.has(name.toLowerCase())) continue;
      // Confirm: find a price in the next few lines
      for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
        const nxt = lines[j].trim();
        if (!nxt) continue;
        if (PRICE_RE.test(nxt)) {
          seenNames.add(name.toLowerCase());
          const { price, description } = lookAheadInfo(lines, i, nameLine);
          products.push({ name, price: price || null, description });
        }
        break;
      }
    }

    return products;
  }

  // ── Dedup & pair responses with their prompts ────────────────────────────
  // allEntries comes from background.js already paired, but we do a text-level
  // dedup here as a final safety net before analysis.

  function buildPairs(entries) {
    // entries is already sorted oldest→newest and paired by background.js
    const pairs = [];
    let lastPrompt = "";
    const seenResponseTexts = new Set();

    for (const entry of entries) {
      if (entry.type === "prompt") {
        lastPrompt = entry.text || "";
        continue;
      }
      if (entry.type !== "response" || !entry.text) continue;
      // Dedup by exact text+url key
      const key = entry.text + "|||" + entry.url;
      if (seenResponseTexts.has(key)) continue;
      seenResponseTexts.add(key);
      pairs.push({ entry, prompt: lastPrompt });
    }
    return pairs;
  }

  // ── Analyze a single response ─────────────────────────────────────────────

  function analyzeResponse(responseEntry, prompt, responseId, total) {
    const text = responseEntry.text || "";
    const products  = extractProducts(text);
    const prices    = extractPrices(text);
    const keywords  = extractKeywords(text);
    const signals   = detectSignals(text);

    return {
      response_id:       responseId,
      total_responses:   total,
      service:           responseEntry.service || "Unknown",
      timestamp:         responseEntry.timestamp || "",
      url:               responseEntry.url || "",
      query:             prompt,
      product_count:     products.length,
      product_names:     products.map(p => p.name).join(" | ") || "—",
      prices_found:      prices.join(" | ") || "—",
      product_details:   products.map(p =>
        `${p.name} [${p.price || "N/A"}]: ${p.description.slice(0, 120)}`
      ).join(" || ") || "—",
      keyword_tags:      keywords.join(", ") || "—",
      has_price:         signals.has_price,
      has_comparison:    signals.has_comparison,
      has_sentiment:     signals.has_sentiment,
      has_features:      signals.has_features,
      word_count:        text.split(/\s+/).filter(Boolean).length,
      char_count:        text.length,
      response_preview:  text.slice(0, 200).replace(/\n/g, " ") + (text.length > 200 ? "…" : ""),
    };
  }

  // ── Public: run full analysis on allEntries array ────────────────────────

  function analyze(allEntries) {
    const pairs   = buildPairs(allEntries);
    const total   = pairs.length;
    return pairs.map(({ entry, prompt }, i) =>
      analyzeResponse(entry, prompt, i + 1, total)
    );
  }

  // ── Public: build analyzed CSV string ────────────────────────────────────

  const CSV_HEADERS = [
    "response_id", "total_responses", "service", "timestamp", "url",
    "query",
    "product_count", "product_names", "prices_found", "product_details",
    "keyword_tags",
    "has_price", "has_comparison", "has_sentiment", "has_features",
    "word_count", "char_count",
    "response_preview",
  ];

  function toCSV(analyzedRows) {
    const escape = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const rows = analyzedRows.map(row =>
      CSV_HEADERS.map(h => escape(row[h])).join(",")
    );
    return [CSV_HEADERS.join(","), ...rows].join("\n");
  }

  return { analyze, toCSV, CSV_HEADERS };

})();
