// ShopSmart — Unified Content Script  v1.3
// Layer 1: Shopping capture  → saves prompt/response pairs to chrome.storage
// Layer 2: Shopping UI       → rewrites responses into interactive product cards
//
// Fixed bugs vs v1.2:
//   BUG1 — Index drift: promptEls were filtered (dropping empties) while
//           responseEls were unfiltered, causing index misalignment and UI
//           transforms never firing. Fix: use unfiltered parallel arrays.
//   BUG2 — uiProcessed marked before shopping check, permanently skipping
//           elements on the first non-shopping pass. Fix: mark only on match.
//   BUG3 — contentEl resolver could return the wrong element on ChatGPT,
//           so extractProductSections found no <strong> nodes. Fix: multi-
//           strategy resolver with querySelector fallback chain.

(function () {
  "use strict";

  // =========================================================================
  // PLATFORM CONFIG
  // =========================================================================

  const PLATFORMS = {
    "chatgpt.com": {
      name: "ChatGPT",
      container: "main",
      promptSelector:   '[data-message-author-role="user"]',
      responseSelector: '[data-message-author-role="assistant"]',
      contentSelectors: [".markdown", ".prose", "[class*='markdown']"],
    },
    "chat.openai.com": {
      name: "ChatGPT",
      container: "main",
      promptSelector:   '[data-message-author-role="user"]',
      responseSelector: '[data-message-author-role="assistant"]',
      contentSelectors: [".markdown", ".prose", "[class*='markdown']"],
    },
    "perplexity.ai": {
      name: "Perplexity",
      container: "main",
      promptSelector:   ".my-md.md\\:my-lg",
      responseSelector: ".prose",
      contentSelectors: [".prose"],
    },
    "claude.ai": {
      name: "Claude",
      container: "main",
      promptSelector:   '[data-testid="user-message"]',
      responseSelector: '[data-testid="assistant-message"]',
      contentSelectors: ['[data-testid="assistant-message"]', ".prose", "article"],
    },
  };

  const hostname    = window.location.hostname.replace("www.", "");
  const platformKey = Object.keys(PLATFORMS).find((k) => hostname.includes(k));
  if (!platformKey) return;
  const platform = PLATFORMS[platformKey];

  // =========================================================================
  // SHOPPING DETECTION — shared by both layers
  // =========================================================================

  const SHOPPING_KEYWORDS = [
    "buy", "buying", "purchase", "shop", "shopping",
    "price", "pricing", "cost", "costs",
    "cheap", "cheapest", "affordable", "budget",
    "best", "top", "recommend", "recommendation",
    "compare", "comparison", "versus", "vs",
    "deal", "deals", "discount", "sale",
    "review", "reviews", "rating", "ratings",
    "specs", "specifications",
    "worth it", "worth buying",
    "upgrade", "alternative", "alternatives",
    "where to buy", "where can i get",
  ];

  const PRODUCT_HINTS = [
    "laptop", "phone", "tablet", "monitor", "headphones", "earbuds",
    "camera", "tv", "television", "speaker", "keyboard", "mouse",
    "gpu", "graphics card", "cpu", "processor", "ssd", "ram",
    "watch", "smartwatch", "fitness tracker",
    "console", "playstation", "xbox", "switch",
    "shoes", "sneakers", "boots", "jacket", "backpack", "shirt", "pants",
    "mattress", "desk", "chair", "office chair", "couch", "sofa",
    "blender", "microwave", "air fryer", "vacuum",
    "car", "bike", "scooter", "ebike",
    "drill", "saw", "tools", "mower",
    "vending machine", "treadmill",
  ];

  const SHOPPING_PATTERNS = [
    /what('s| is) the best .+ (for|under|around)/i,
    /which .+ should i (buy|get|pick)/i,
    /looking for (a|an|the|some) .+/i,
    /recommend .+ (for|under|around)/i,
    /how much (does|do|is|are) .+/i,
    /is (the |it |this )?.+ worth/i,
    /\$\d+/,
    /.+ or .+ \?/i,
    /best .+ (under|for|in) .+/i,
  ];

  function isShoppingRelated(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    let score = 0;
    for (const kw of SHOPPING_KEYWORDS) { if (lower.includes(kw)) score += 1; }
    for (const h  of PRODUCT_HINTS)     { if (lower.includes(h))  score += 2; }
    for (const p  of SHOPPING_PATTERNS) { if (p.test(text))        score += 2; }
    return score >= 2;
  }

  // =========================================================================
  // STABILITY DETECTOR — shared, single copy
  // =========================================================================

  function waitForStable(el, stableMs = 1200) {
    return new Promise((resolve) => {
      if (!el) { resolve(null); return; }
      let timer = setTimeout(() => { obs.disconnect(); resolve(el); }, stableMs);
      const obs = new MutationObserver(() => {
        clearTimeout(timer);
        timer = setTimeout(() => { obs.disconnect(); resolve(el); }, stableMs);
      });
      obs.observe(el, { childList: true, subtree: true, characterData: true });
    });
  }

  // =========================================================================
  // LAYER 1 — CAPTURE
  // =========================================================================

  const seenPromptEls       = new WeakSet();
  const seenResponseEls     = new WeakSet();
  const pendingCapture      = new WeakSet();
  const shoppingPromptTexts = new Set();
  const promptPairMap       = new WeakMap(); // promptEl → pairIndex
  let   pairIndex           = 0;

  function saveEntry(type, text, idx) {
    chrome.runtime.sendMessage({
      action: "save_entry",
      entry: { type, text, service: platform.name, url: window.location.href,
               timestamp: new Date().toISOString(), pairIndex: idx },
    });
  }

  // ── Prompt capture ─────────────────────────────────────────────────────────
  // Strategy: hook the form submit / button click / Enter keypress so we
  // capture the prompt at the exact moment the user sends it — not during
  // typing. This fires before ChatGPT replaces the input with the rendered
  // message element, so we always get the complete text.

  let pendingPromptText = ""; // text staged at send-time, consumed by scan()

  function hookSendEvents() {
    // Works across ChatGPT, Perplexity, Claude
    // 1. Enter key in contenteditable / textarea
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.shiftKey) return;
      const active = document.activeElement;
      if (!active) return;
      const tag = active.tagName;
      if (tag === "TEXTAREA" || active.isContentEditable || tag === "INPUT") {
        const text = (active.value || active.innerText || "").trim();
        if (text) pendingPromptText = text;
      }
    }, true);

    // 2. Click on send button (covers mouse clicks and touch)
    document.addEventListener("click", (e) => {
      const btn = e.target.closest(
        'button[data-testid="send-button"], button[aria-label*="Send"], ' +
        'button[aria-label*="send"], button[type="submit"]'
      );
      if (!btn) return;
      // Find the nearest input/textarea/contenteditable
      const form = btn.closest("form") || btn.closest('[role="presentation"]') || document.body;
      const input = form.querySelector("textarea, [contenteditable='true']");
      if (input) {
        const text = (input.value || input.innerText || "").trim();
        if (text) pendingPromptText = text;
      }
    }, true);
  }

  function runCaptureLayer(allPromptEls, allResponseEls) {
    // ── Prompts ────────────────────────────────────────────────────────────
    // After send, the AI platform renders the prompt text into a message
    // element. We match it against pendingPromptText (captured at send-time)
    // to get the definitive full text with zero timing ambiguity.
    allPromptEls.forEach((el) => {
      if (seenPromptEls.has(el)) return;

      const domText = el.innerText?.trim() || "";
      if (!domText) return;
      seenPromptEls.add(el);

      // Use the send-time snapshot if it matches this element's text
      // (same prefix, allowing for minor whitespace differences).
      const text = (
        pendingPromptText &&
        (domText.startsWith(pendingPromptText.slice(0, 40)) ||
         pendingPromptText.startsWith(domText.slice(0, 40)))
      ) ? pendingPromptText : domText;

      // Clear the staging slot now that it's been consumed
      if (text === pendingPromptText) pendingPromptText = "";

      if (isShoppingRelated(text) && !promptPairMap.has(el)) {
        const idx = pairIndex++;
        promptPairMap.set(el, idx);
        shoppingPromptTexts.add(text);
        saveEntry("prompt", text, idx);
        console.log(`[ShopSmart] 📝 Prompt #${idx}: "${text.slice(0, 80)}"`);
      }
    });

    // ── Responses ──────────────────────────────────────────────────────────
    // Attach a continuous raw-text tracker to each new response element.
    // The tracker records innerText on every streaming mutation into
    // el._ssRawText, but watches the DOCUMENT ROOT for the banner so it
    // doesn't miss it regardless of which child element it's injected into.
    // A completion poller then fires once streaming has truly stopped.
    allResponseEls.forEach((el, i) => {
      if (seenResponseEls.has(el) || pendingCapture.has(el)) return;
      pendingCapture.add(el);

      const promptEl = allPromptEls[i];
      el._ssRawText  = "";
      let bannerSeen = false;

      // Track the raw text as the response streams in
      const tracker = new MutationObserver(() => {
        // Detect banner anywhere inside the response wrapper or its resolved
        // content element — covers both deep and shallow injection points
        if (!bannerSeen) {
          const contentEl = resolveContentEl(el);
          if ((contentEl && contentEl.querySelector(".pv-mode-banner")) ||
              el.querySelector(".pv-mode-banner")) {
            bannerSeen = true;
            tracker.disconnect();
            return;
          }
        }
        const t = el.innerText?.trim() || "";
        if (t) el._ssRawText = t;
      });
      tracker.observe(el, { childList: true, subtree: true, characterData: true });

      // Poll every 300ms to detect when streaming has stopped.
      // Streaming is "done" when the text hasn't changed for 2 consecutive
      // polls AND the element is no longer in a "generating" state.
      // This avoids the waitForStable reset-on-mutation problem.
      let lastLen   = 0;
      let stableFor = 0;
      const poll = setInterval(() => {
        const currentLen = (el._ssRawText || el.innerText || "").length;

        if (currentLen === lastLen && currentLen > 0) {
          stableFor += 300;
        } else {
          stableFor = 0;
          lastLen   = currentLen;
          // Update snapshot while streaming
          if (!bannerSeen) {
            const t = el.innerText?.trim() || "";
            if (t) el._ssRawText = t;
          }
        }

        // Stable for 1.2s = streaming done
        if (stableFor >= 1200) {
          clearInterval(poll);
          tracker.disconnect();

          const finalText = el._ssRawText || "";
          if (!finalText) { pendingCapture.delete(el); return; }

          // Verify the matched prompt was shopping-related
          const promptText = promptEl?.innerText?.trim() || "";
          const isShopping = shoppingPromptTexts.has(promptText) ||
            [...shoppingPromptTexts].some(t =>
              promptText.slice(0, 40) === t.slice(0, 40)
            );

          if (!isShopping) { pendingCapture.delete(el); return; }

          const idx = promptPairMap.get(promptEl) ?? i;
          seenResponseEls.add(el);
          saveEntry("response", finalText, idx);
          console.log(`[ShopSmart] 💾 Saved ${finalText.length} chars, pair #${idx}`);
        }
      }, 300);
    });
  }

  // =========================================================================
  // LAYER 2 — UI TRANSFORM
  // =========================================================================

  const uiProcessed = new WeakSet();

  // ── Utility ───────────────────────────────────────────────────────────────

  function esc(str) {
    const d = document.createElement("div");
    d.textContent = str;
    return d.innerHTML;
  }

  function cleanName(raw) {
    return raw.replace(/[*_`]/g, "").replace(/^\d+\.\s*/, "").replace(/[:—–\-]\s*$/, "").trim();
  }

  function looksLikeProduct(name) {
    if (name.length < 3 || name.length > 80) return false;
    const skipWords = [
      "pros","cons","features","summary","conclusion","overview","note","tip",
      "warning","option","here are","things to consider","key factors",
      "final thoughts","bottom line","important",
    ];
    const lower = name.toLowerCase();
    if (skipWords.some((t) => lower === t || lower.startsWith(t))) return false;
    return /[A-Z]/.test(name) && (/\d/.test(name) || name.split(" ").length > 1);
  }

  function parseContextText(text) {
    const clean      = text.replace(/^[\s:—–\-]+/, "").trim();
    const priceMatch = clean.match(/\$[\d,]+(?:\s*[-–—to]+\s*\$[\d,]+)?/);
    const priceRange = priceMatch ? priceMatch[0] : null;

    const specPatterns = [
      /\d+\s*(?:GB|TB|MB)\s*(?:RAM|SSD|storage|memory)/gi,
      /\d+\.?\d*[\s-]*inch/gi,
      /\d+\s*(?:mAh|W|Hz|MP)/gi,
      /\d+\s*(?:hours?|hrs?)\s*battery/gi,
      /(?:IP)\d{2}/gi,
    ];
    const specs = [];
    for (const p of specPatterns) { const m = clean.match(p); if (m) specs.push(...m); }

    let description = clean;
    if (priceRange) description = description.replace(priceMatch[0], "").trim();
    if (description.length > 180) description = description.slice(0, 177) + "...";

    return { description: description || null, specs: specs.length ? specs : null, priceRange };
  }

  function parseContext(block, boldEl) {
    const full  = block ? block.textContent : "";
    const after = full.split(boldEl.textContent).slice(1).join("").trim();
    return parseContextText(after);
  }

  // BUG3 FIX — multi-strategy content element resolver
  function resolveContentEl(responseEl) {
    // Try each contentSelector inside the response element itself first
    for (const sel of platform.contentSelectors) {
      const found = responseEl.querySelector(sel);
      if (found) return found;
    }
    // Try walking up to a conversation turn and searching inside it
    const turn = responseEl.closest('[data-testid^="conversation-turn"]')
              || responseEl.closest("article")
              || responseEl.parentElement;
    if (turn) {
      for (const sel of platform.contentSelectors) {
        const found = turn.querySelector(sel);
        if (found) return found;
      }
    }
    // Last resort: use the response element itself
    return responseEl;
  }

  // ── Product extraction ────────────────────────────────────────────────────

  function extractProductSections(contentEl) {
    const sections = [];
    const seen     = new Set();

    // Strategy 1: bold/strong names — most common in AI shopping responses
    for (const bold of contentEl.querySelectorAll("strong, b")) {
      const name = cleanName(bold.textContent);
      if (!name || seen.has(name.toLowerCase()) || !looksLikeProduct(name)) continue;
      seen.add(name.toLowerCase());
      const block = bold.closest("li") || bold.closest("p") || bold.parentElement;
      sections.push({ name, element: bold, block, ...parseContext(block, bold) });
    }

    // Strategy 2: list items with product-like headings (fallback)
    if (sections.length === 0) {
      for (const li of contentEl.querySelectorAll("li")) {
        const text  = li.textContent.trim();
        const match = text.match(/^(?:\d+\.\s*)?([A-Z][\w\s\-]+(?:\d{2,}[\w]*)?)/);
        if (!match) continue;
        const name = cleanName(match[1]);
        if (!name || seen.has(name.toLowerCase()) || !looksLikeProduct(name)) continue;
        seen.add(name.toLowerCase());
        sections.push({ name, element: null, block: li, ...parseContextText(text.slice(match[0].length)) });
      }
    }

    return sections;
  }

  // ── DOM transforms ────────────────────────────────────────────────────────

  function applyShoppingWrapper(responseEl) {
    const wrapper = responseEl.closest("article")
                 || responseEl.closest('[data-testid^="conversation-turn"]')
                 || responseEl.closest(".group")
                 || responseEl;
    wrapper.classList.add("pv-shopping-mode");
  }

  function injectBanner(contentEl) {
    if (contentEl.querySelector(".pv-mode-banner")) return; // idempotent
    const banner = document.createElement("div");
    banner.className = "pv-mode-banner";
    banner.innerHTML = `
      <span class="pv-mode-icon">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"
             stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
        </svg>
      </span>
      <span class="pv-mode-text">Shopping Mode</span>`;
    contentEl.insertBefore(banner, contentEl.firstChild);
  }

  function buildBuyLinks(encoded) {
    return `
      <a href="https://www.amazon.com/s?k=${encoded}"                       target="_blank" rel="noopener">Amazon</a>
      <a href="https://www.google.com/search?tbm=shop&q=${encoded}"         target="_blank" rel="noopener">Google</a>
      <a href="https://www.bestbuy.com/site/searchpage.jsp?st=${encoded}"   target="_blank" rel="noopener">Best Buy</a>
      <a href="https://www.google.com/search?q=${encoded}+review"           target="_blank" rel="noopener">Reviews</a>`;
  }

  function transformProductInline(boldEl, product) {
    const encoded  = encodeURIComponent(product.name);
    const chip     = document.createElement("span");
    chip.className = "pv-product-chip";
    chip.textContent = product.name;

    const popover      = document.createElement("div");
    popover.className  = "pv-product-popover";

    let inner = `<div class="pv-pop-name">${esc(product.name)}</div>`;
    if (product.priceRange) {
      inner += `<div class="pv-pop-price">${esc(product.priceRange)}</div>`;
    }
    if (product.specs?.length) {
      inner += `<div class="pv-pop-specs">${
        product.specs.map((s) => `<span class="pv-pop-spec">${esc(s)}</span>`).join("")
      }</div>`;
    }
    inner += `<div class="pv-pop-links">${buildBuyLinks(encoded)}</div>`;

    popover.innerHTML = inner;
    chip.appendChild(popover);
    boldEl.replaceWith(chip);
  }

  function transformProductList(sections) {
    const byParent = new Map();
    for (const sec of sections) {
      if (!sec.block || sec.block.tagName !== "LI") continue;
      const parent = sec.block.parentElement;
      if (!parent) continue;
      if (!byParent.has(parent)) byParent.set(parent, []);
      byParent.get(parent).push(sec);
    }

    for (const [listEl, products] of byParent) {
      if (products.length < 2) continue;

      const grid     = document.createElement("div");
      grid.className = "pv-product-grid";

      for (const product of products) {
        const encoded  = encodeURIComponent(product.name);
        const card     = document.createElement("div");
        card.className = "pv-grid-card";

        let html = `
          <div class="pv-grid-header">
            <span class="pv-grid-name">${esc(product.name)}</span>
            ${product.priceRange ? `<span class="pv-grid-price">${esc(product.priceRange)}</span>` : ""}
          </div>`;
        if (product.description) {
          html += `<p class="pv-grid-desc">${esc(product.description)}</p>`;
        }
        if (product.specs?.length) {
          html += `<div class="pv-grid-specs">${
            product.specs.map((s) => `<span class="pv-grid-spec">${esc(s)}</span>`).join("")
          }</div>`;
        }
        html += `<div class="pv-grid-links">${buildBuyLinks(encoded)}</div>`;

        card.innerHTML = html;
        grid.appendChild(card);
      }

      listEl.replaceWith(grid);
    }
  }

  // ── Main UI layer entry point ─────────────────────────────────────────────

  function runUILayer(responseEl, promptText) {
    // BUG2 FIX: check shopping intent BEFORE marking as processed
    if (!isShoppingRelated(promptText)) return;
    if (uiProcessed.has(responseEl)) return;
    uiProcessed.add(responseEl);

    // BUG3 FIX: use multi-strategy content resolver
    const contentEl = resolveContentEl(responseEl);

    // Poll until the content stops growing, then transform.
    // Polling is immune to the waitForStable reset-on-every-token problem.
    let uiLastLen   = 0;
    let uiStableFor = 0;
    const uiPoll = setInterval(() => {
      const currentLen = contentEl.innerText?.length || 0;
      if (currentLen === uiLastLen && currentLen > 0) {
        uiStableFor += 200;
      } else {
        uiStableFor = 0;
        uiLastLen   = currentLen;
      }

      if (uiStableFor >= 800) {
        clearInterval(uiPoll);

        if (contentEl.querySelector(".pv-mode-banner")) return; // already done

        const sections = extractProductSections(contentEl);
        console.log(`[ShopSmart] 🛍 ${sections.length} product(s) found — transforming`);

        applyShoppingWrapper(responseEl);
        injectBanner(contentEl);
        if (sections.length >= 2) transformProductList(sections);
        const remaining = extractProductSections(contentEl);
        for (const sec of remaining) {
          if (sec.element?.isConnected) transformProductInline(sec.element, sec);
        }
      }
    }, 200);
  }

  // =========================================================================
  // MAIN SCAN — both layers, aligned indices
  // =========================================================================

  function scan() {
    // BUG1 FIX: keep both arrays unfiltered so index i means the same
    // conversation turn in both lists
    const allPromptEls   = Array.from(document.querySelectorAll(platform.promptSelector));
    const allResponseEls = Array.from(document.querySelectorAll(platform.responseSelector));

    runCaptureLayer(allPromptEls, allResponseEls);

    // UI layer uses the same aligned index
    allResponseEls.forEach((el, i) => {
      const promptText = allPromptEls[i]?.innerText?.trim() || "";
      runUILayer(el, promptText);
    });
  }

  // =========================================================================
  // BOOT
  // =========================================================================

  function start() {
    hookSendEvents();
    const container = document.querySelector(platform.container) || document.body;
    const observer  = new MutationObserver(() => scan());
    observer.observe(container, { childList: true, subtree: true });
    scan();
    console.log(`[ShopSmart] ✅ v1.3 active on ${platform.name}`);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(start, 1500));
  } else {
    setTimeout(start, 1500);
  }

})();
